## **GENMODEL PARAMETER ENGINE**
## Purpose-built for FlowTask 
## PARAMETER ENGINE VER 1.1
## Written by Sidharth Prasad 
## Update Dated ; 15th Sep 2024

print("GENMODEL VER 1.1")
print("GENMODEL.PY is RUNNING")

data1 = "Based on this data"

pm1 = "Provide a concise"
pm2 = "20-30 word insight in plain text"
pm3 = "as a simple, clear sentence or paragraph"
pm4 = "without using any formatting like markdown, or using special characters like `*` for emphasis"
pm5 = "Explain how to efficiently manage the given tasks"
pm6 = "List the tasks and propose an actionable plan"
pm7 = "Include a suggested time framework for each task"
pm8 = "Use hours and half an hours as the unit for time allocation"
pm9 = "Refrain from referring to specific dates, times, or days"
pm10 = "Assume the user’s timeline is flexible and unknown"
pm11 = "Talk like you're giving the user some normal conversation but still keep it professional and not too informal"
pm12 = "Don't Drop in table formatting or special characters. have plain conversation."
pm13 = "Use correct units for advice. dont just say `couple hours` or `some time` say correct time units." 
pm14 = "also refrain from using quotes while referring to tasks. you dont have to religiously follow the data given name."

pmList = [pm1,pm2,pm3,pm4,pm5,pm6,pm7,pm8,pm9,pm10,pm11,pm12,pm13,pm14]

def genPrompt():
    global glPrompt
    glPrompt = ' '.join(pmList)
    print("[PM ENGINE 1.1] Instance RUN")
    
genPrompt()
