## **FLOW ALGO ENGINE**
## Purpose-built for FlowTask
## ALGO ENGINE VER 1.1
## Written by <<AUTHOR>>
## Update Dated ; 15th Sep 2024

print("FLOW ALGO VER 1.0")

algoRating = 50

list1 = [1,2,3,4]
list2 = [1,2,3,4]

def currentSaver(list):
    global currentLen
    print("[i0N] loaded")
    currentLen = len(list)

def incrementCounter(list):
    global algoRating
    submittedLen = len(list)
    if submittedLen < currentLen:
        print("verified")
        algoRating += 1
        print(algoRating)
    else:
        print("unverifiable")

def errorHandling():
    print("errors cannot be handled [1]")

## running test case 1

currentSaver(list1)
list1.pop()
incrementCounter(list1)
