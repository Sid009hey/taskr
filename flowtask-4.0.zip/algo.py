## **FLOW ALGO ENGINE**
## Purpose-built for FlowTask 
## ALGO ENGINE VER 1.1
## Written by <<AUTHOR>> 
## Update Dated ; 15th Sep 2024

print("FLOW ALGO VER 1.0")
